package com.codepath.android.booksearch.models;

import android.app.Application;

import com.codepath.android.booksearch.activities.BookListActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Globals extends Application {
    public boolean allowRefresh = false;
    private List<Book> gBooks = new ArrayList<Book>();

    public ArrayList<Book> getData(){
        return (ArrayList<Book>) this.gBooks;
    }
    public void setData(Book b){
        this.gBooks.add(b);
    }
    public void deleteData(Book b){
        this.gBooks.remove(b);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            FileInputStream fin = openFileInput("budizKniha");
            InputStreamReader isr = new InputStreamReader(fin);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line);
            }

            String[] lines = sb.toString().split("TADYjeOdDelovac");
            for(String s: lines){
                System.out.println("Content = " + s);
                Object obj = Book.stringToObject(s);
                Book bo = (Book)obj;
                gBooks.add(bo);
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
