package com.codepath.android.booksearch;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.codepath.android.booksearch.activities.BookDetailActivity;
import com.codepath.android.booksearch.adapters.BookAdapter;
import com.codepath.android.booksearch.adapters.IBookAdapterItemClickListener;
import com.codepath.android.booksearch.models.Book;
import com.codepath.android.booksearch.models.Globals;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class HistoryFragment extends Fragment {
    private RecyclerView rvhBooks;
    private BookAdapter bookAdapter;
    private ArrayList<Book> abooks;


    public HistoryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        container.removeAllViews();
        View rootView = inflater.inflate(R.layout.fragment_history, container, false);

        rvhBooks = (RecyclerView) rootView.findViewById(R.id.rvhBooks);
        abooks = new ArrayList<>();

        Globals application = (Globals) getActivity().getApplication();

        if (application != null){
            abooks = application.getData();
        }

        bookAdapter = new BookAdapter(getContext(), abooks, new IBookAdapterItemClickListener() {
            @Override
            public void onItemClicked(int pos) {
                Globals application = (Globals) getActivity().getApplication();
                Book book = bookAdapter.getItem(pos);
                application.deleteData(bookAdapter.getItem(pos));
                Intent intent = new Intent(getActivity(), BookDetailActivity.class);
                intent.putExtra("book", book);
                startActivity(intent);
            }
        });

        rvhBooks.setAdapter(bookAdapter);

        rvhBooks.setLayoutManager(new LinearLayoutManager(getContext()));


        // Inflate the layout for this fragment
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();

        Globals globals = (Globals) getActivity().getApplication();
        if (globals.allowRefresh)
        {
            globals.allowRefresh = false;
            //lst_applist = db.load_apps();
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        menu.clear();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }
}
