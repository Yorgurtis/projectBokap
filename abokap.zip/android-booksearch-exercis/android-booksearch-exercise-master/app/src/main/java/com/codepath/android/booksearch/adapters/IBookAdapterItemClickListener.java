package com.codepath.android.booksearch.adapters;

public interface IBookAdapterItemClickListener {
    void onItemClicked(int pos);
}
