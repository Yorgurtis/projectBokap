package com.codepath.android.booksearch.models;

import android.text.TextUtils;
import android.util.Base64InputStream;
import android.util.Base64OutputStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Book implements Serializable {
    private String id;
    private String author;
    private String title;
    private String cover;
    private String pageCount;
    private String category;
    private String publisher;


    public String getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public String getCoverUrl() {
        return cover;
    }
    public String getPageCount(){return pageCount;}
    public String getCategory(){return category;}
    public String getPublisher(){return publisher;}

    // Returns a Book given the expected JSON
    public static Book fromJson(JSONObject jsonObject) {
        Book book = new Book();
        try {
            // Deserialize json into object fields
            // Check if a cover edition is available
            JSONObject volume = jsonObject.getJSONObject("volumeInfo");
            JSONObject thumbnail = volume.getJSONObject("imageLinks");

            book.pageCount = volume.has("pageCount") ? volume.getString("pageCount") : "";
            book.publisher = volume.has("publisher") ? volume.getString("publisher") : "";
            book.cover = thumbnail.has("thumbnail") ? thumbnail.getString("thumbnail") : "";
            book.title = volume.has("title") ? volume.getString("title") : "";
            book.author = getAuthor(volume);
            book.category = getCategory(volume);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        // Return new object
        return book;
    }

    // Return comma separated author list when there is more than one author
    private static String getAuthor(final JSONObject jsonObject) {
        try {
            final JSONArray authors = jsonObject.getJSONArray("authors");
            int numAuthors = authors.length();
            final String[] authorStrings = new String[numAuthors];
            for (int i = 0; i < numAuthors; ++i) {
                authorStrings[i] = authors.getString(i);
            }
            return TextUtils.join(", ", authorStrings);
        } catch (JSONException e) {
            return "";
        }
    }

    // Return comma separated author list when there is more than one author
    private static String getCategory(final JSONObject jsonObject) {
        try {
            final JSONArray categories = jsonObject.getJSONArray("categories");
            int numCategories = categories.length();
            final String[] categoryStrings = new String[numCategories];
            for (int i = 0; i < numCategories; ++i) {
                categoryStrings[i] = categories.getString(i);
            }
            return TextUtils.join(", ", categoryStrings);
        } catch (JSONException e) {
            return "";
        }
    }

    // Decodes array of book json results into business model objects
    public static ArrayList<Book> fromJson(JSONArray jsonArray) {
        ArrayList<Book> books = new ArrayList<>(jsonArray.length());
        // Process each result in json array, decode and convert to business
        // object
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject bookJson;
            try {
                bookJson = jsonArray.getJSONObject(i);
            } catch (Exception e) {
                e.printStackTrace();
                continue;
            }
            Book book = Book.fromJson(bookJson);
            if (book != null) {
                books.add(book);
            }
        }
        return books;
    }




    public static String objectToString(Serializable object) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            new ObjectOutputStream(out).writeObject(object);
            byte[] data = out.toByteArray();
            out.close();

            out = new ByteArrayOutputStream();
            Base64OutputStream b64 = new Base64OutputStream(out,0);
            b64.write(data);
            b64.close();
            out.close();

            return new String(out.toByteArray());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Object stringToObject(String encodedObject) {
        try {
            return new ObjectInputStream(new Base64InputStream(
                    new ByteArrayInputStream(encodedObject.getBytes()), 0)).readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
