package com.codepath.android.booksearch.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import com.codepath.android.booksearch.HistoryFragment;
import com.codepath.android.booksearch.HomeFragment;
import com.codepath.android.booksearch.R;
import com.codepath.android.booksearch.SettingsFragment;
import com.codepath.android.booksearch.adapters.BookAdapter;
import com.codepath.android.booksearch.adapters.IBookAdapterItemClickListener;
import com.codepath.android.booksearch.models.Book;
import com.codepath.android.booksearch.models.Globals;
import com.codepath.android.booksearch.net.BookClient;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;


public class BookListActivity extends AppCompatActivity {
    public static final String BOOK_DETAIL_KEY = "book";

    private BottomNavigationView mbottomNavigationView;
    private FrameLayout mframeLayout;

    private HomeFragment homeFragment;
    private HistoryFragment historyFragment;
    private SettingsFragment settingsFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_list);

        mbottomNavigationView = (BottomNavigationView) findViewById(R.id.navBar);
        mframeLayout = (FrameLayout) findViewById(R.id.frameLay);

        homeFragment = new HomeFragment();
        historyFragment = new HistoryFragment();
        settingsFragment = new SettingsFragment();

        setFragment(homeFragment);

        mbottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.nav_home:
                        setTitle("Home");
                        setFragment(homeFragment);
                        return true;
                    case R.id.nav_history:
                        setTitle("History");
                        setFragment(historyFragment);
                        return true;
                    case R.id.nav_settings:
                        setTitle("Settings");
                        setFragment(settingsFragment);
                        return true;
                    default:
                        return false;
                }

            }
        });

    }

    private void setFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frameLay, fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
/*
        Globals application = (Globals) getApplication();
        ArrayList<Book> books = application.getData();

        for (Book book : books){
            String strBook = book.objectToString(book);

            String filename = "budizKniha";
            FileOutputStream outputStream;
            try {
                outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                outputStream.write(strBook.getBytes());
                outputStream.write("\\n".getBytes());
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }*/
    }

    public void globalLoad(){

        Globals application = (Globals) getApplication();
        try {
            FileInputStream fin = openFileInput("budizKniha");
            InputStreamReader isr = new InputStreamReader(fin);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line);
            }

            String[] lines = sb.toString().split("TADYjeOdDelovac");
            for(String s: lines){
                System.out.println("Content = " + s);
                Object obj = Book.stringToObject(s);
                Book bo = (Book)obj;
                application.setData(bo);
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
