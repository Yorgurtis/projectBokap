package com.codepath.android.booksearch.activities;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.codepath.android.booksearch.GlideApp;
import com.codepath.android.booksearch.HistoryFragment;
import com.codepath.android.booksearch.HomeFragment;
import com.codepath.android.booksearch.R;
import com.codepath.android.booksearch.SettingsFragment;
import com.codepath.android.booksearch.adapters.BookAdapter;
import com.codepath.android.booksearch.adapters.IBookAdapterItemClickListener;
import com.codepath.android.booksearch.models.Book;
import com.codepath.android.booksearch.models.Globals;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class BookDetailActivity extends AppCompatActivity {
    private ImageView ivBookCover;
    private TextView tvTitle;
    private TextView tvAuthor;
    private TextView tvPublisher;
    private TextView tvPageCount;
    private TextView tvCategory;

    private BottomNavigationView mbottomNavigationView;
    private FrameLayout mframeLayout;

    private HomeFragment homeFragment;
    private HistoryFragment historyFragment;
    private SettingsFragment settingsFragment;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        mbottomNavigationView = (BottomNavigationView) findViewById(R.id.navBar);
        mframeLayout = (FrameLayout) findViewById(R.id.frameLay);

        homeFragment = new HomeFragment();
        historyFragment = new HistoryFragment();
        settingsFragment = new SettingsFragment();

        //setFragment(homeFragment);

        mbottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.nav_home:
                        startActivity(new Intent(BookDetailActivity.this, BookListActivity.class));
                        //finish for back button
                        //finish();
                        //setTitle("Home");
                        //setFragment(homeFragment);
                        return true;
                    case R.id.nav_history:
                        setTitle("History");
                        setFragment(historyFragment);
                        return true;
                    case R.id.nav_settings:
                        setTitle("Settings");
                        setFragment(settingsFragment);
                        return true;
                    default:
                        return false;
                }

            }
        });
        // Fetch views
        ivBookCover = (ImageView) findViewById(R.id.ivBookCover);
        tvTitle = (TextView) findViewById(R.id.tvTitle);
        tvAuthor = (TextView) findViewById(R.id.tvAuthor);
        tvCategory = (TextView) findViewById(R.id.tvCategory);
        tvPublisher = (TextView) findViewById(R.id.tvPublisher);
        tvPageCount = (TextView) findViewById(R.id.tvPageCount);

        Book book = (Book) getIntent().getSerializableExtra(BookListActivity.BOOK_DETAIL_KEY);
        // Use book object to populate data into views

        Globals application = (Globals) getApplication();
        if (application != null){
            application.setData(book);
        }

            String strBook = book.objectToString(book);

            String filename = "budizKniha";
            FileOutputStream outputStream;
            try {
                outputStream = openFileOutput(filename, Context.MODE_APPEND);
                outputStream.write(strBook.getBytes());
                outputStream.write("TADYjeOdDelovac".getBytes());
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        loadBook(book);
    }

    private void loadBook(Book book) {
        this.setTitle(book.getTitle());

        tvTitle.setText(book.getTitle());
        tvAuthor.setText(book.getAuthor());
        tvCategory.setText(book.getCategory());
        tvPublisher.setText(book.getPublisher());
        tvPageCount.setText(book.getPageCount());

        GlideApp.with(this.getBaseContext())
                .load(Uri.parse(book.getCoverUrl()))
                .placeholder(R.drawable.ic_nocover)
                .into(ivBookCover);
    }

    private void setFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frameLay, fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_book_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Globals application = (Globals) getApplication();
            Book book = (Book) getIntent().getSerializableExtra(BookListActivity.BOOK_DETAIL_KEY);
            application.deleteData(book);


            String filename = "budizKniha";
            FileOutputStream outputStream;
            try {
                outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                for (Book bo : application.getData()){
                    String strBook = bo.objectToString(bo);
                    outputStream.write(strBook.getBytes());
                    outputStream.write("TADYjeOdDelovac".getBytes());
                }
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            application.allowRefresh = true;
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
